import React from "react";

function Sayyoh() {
    return (
        <div>
            <h1>Sayyohlar</h1>
        </div>
    );
}

export default Sayyoh;
